import React from 'react'

function Home() {
    return (
        <div >
            <p>WELCOME EVERYONE</p>
            <h1>It is a Home Page</h1>
        </div>
    )
}

export default Home
